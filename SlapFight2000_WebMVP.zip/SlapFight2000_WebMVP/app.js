const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const hp1El = document.getElementById('hp1');
const hp2El = document.getElementById('hp2');
const overlay = document.getElementById('overlay');
const startBtn = document.getElementById('start');

const img = (src)=>{ const i=new Image(); i.src=src; return i; };
const bg = img('assets/background.jpg');
const p1img = img('assets/player1.png');
const p2img = img('assets/player2.png');

let W=0,H=0,dpr=1, running=false, ended=false;
let hp1=100, hp2=100, combo1=0, combo2=0;
let shake=0, flash=0, lastHitText='', lastHitT=0;
const p1={x:0,y:0,hit:0,hurt:0,super:0};
const p2={x:0,y:0,hit:0,hurt:0,super:0};

function resize(){
  dpr=Math.min(2, window.devicePixelRatio || 1);
  W=innerWidth; H=innerHeight;
  canvas.width=W*dpr; canvas.height=H*dpr;
  ctx.setTransform(dpr,0,0,dpr,0,0);
  p1.x=W*.28; p2.x=W*.72; p1.y=p2.y=H*.56;
}
addEventListener('resize', resize); resize();

function reset(){ hp1=hp2=100; combo1=combo2=0; ended=false; running=true; overlay.classList.add('hidden'); }
startBtn.onclick=reset;

function slap(player){
  if(!running || ended) return;
  if(player===1){
    combo1++; const s = combo1%10===0; const dmg=s?18:7; hp2=Math.max(0,hp2-dmg); p1.hit=12; p1.super=s?18:0; p2.hurt=14; boom(s?'SUPER SLAP!':'PATSCH!', s?18:8);
  } else {
    combo2++; const s = combo2%10===0; const dmg=s?18:7; hp1=Math.max(0,hp1-dmg); p2.hit=12; p2.super=s?18:0; p1.hurt=14; boom(s?'SUPER SLAP!':'KLATSCH!', s?18:8);
  }
  if(hp1<=0 || hp2<=0){ ended=true; running=false; setTimeout(()=>{ overlay.classList.remove('hidden'); overlay.querySelector('h1').textContent = hp1<=0?'SPIELER 2 GEWINNT!':'SPIELER 1 GEWINNT!'; overlay.querySelector('p').textContent='Nochmal spielen?'; startBtn.textContent='NEUSTART'; },350); }
}
function boom(text,power){ shake=power; flash=8; lastHitText=text; lastHitT=25; if(navigator.vibrate) navigator.vibrate(power>10?[25,30,25]:18); }
canvas.addEventListener('pointerdown', e=>{ e.preventDefault(); slap(e.clientX<W/2?1:2); }, {passive:false});

function drawFighter(p, img, flip=false){
  ctx.save();
  let dx=(p.hurt?Math.sin(Date.now()/28)*10:0) + (p.hit?(flip?-20:20):0);
  ctx.translate(p.x+dx,p.y);
  if(flip) ctx.scale(-1,1);
  // body
  ctx.fillStyle='#f5cf20'; ctx.strokeStyle='#111'; ctx.lineWidth=5;
  roundRect(ctx,-62,40,124,180,18,true,true);
  ctx.fillStyle='#151515'; ctx.fillRect(-62,53,124,18);
  ctx.fillStyle='#f5cf20'; ctx.fillRect(-50,220,42,90); ctx.fillRect(10,220,42,90);
  ctx.fillStyle='#f0b38b'; ctx.fillRect(-48,305,36,78); ctx.fillRect(14,305,36,78);
  // head
  ctx.drawImage(img,-70,-95,140,140);
  // arm + slap hand
  ctx.strokeStyle='#f0b38b'; ctx.lineWidth=22; ctx.lineCap='round';
  ctx.beginPath(); ctx.moveTo(60,75); ctx.lineTo(p.hit?155:88,30); ctx.stroke();
  ctx.fillStyle='#f0b38b'; ctx.beginPath(); ctx.ellipse(p.hit?168:96,26,20,14,0,0,Math.PI*2); ctx.fill();
  if(p.super){ ctx.fillStyle='rgba(255,240,0,.55)'; ctx.beginPath(); ctx.arc(90,0,95,0,Math.PI*2); ctx.fill(); }
  ctx.restore();
}
function roundRect(c,x,y,w,h,r,fill,stroke){ c.beginPath(); c.roundRect(x,y,w,h,r); if(fill)c.fill(); if(stroke)c.stroke(); }
function draw(){
  requestAnimationFrame(draw);
  if(p1.hit) p1.hit--; if(p2.hit) p2.hit--; if(p1.hurt) p1.hurt--; if(p2.hurt) p2.hurt--; if(p1.super) p1.super--; if(p2.super) p2.super--; if(shake) shake*=.82; if(flash) flash--; if(lastHitT) lastHitT--;
  const sx=(Math.random()-.5)*shake, sy=(Math.random()-.5)*shake;
  ctx.save(); ctx.translate(sx,sy);
  if(bg.complete){ const r=Math.max(W/bg.width,H/bg.height); const bw=bg.width*r,bh=bg.height*r; ctx.drawImage(bg,(W-bw)/2,(H-bh)/2,bw,bh); }
  ctx.fillStyle='rgba(18,30,60,.28)'; ctx.fillRect(0,0,W,H);
  // split/tap zones
  ctx.fillStyle='rgba(255,211,26,.08)'; ctx.fillRect(0,H*.72,W/2,H*.28); ctx.fillRect(W/2,H*.72,W/2,H*.28);
  ctx.strokeStyle='rgba(255,255,255,.45)'; ctx.lineWidth=3; ctx.setLineDash([10,8]); ctx.beginPath(); ctx.moveTo(W/2,H*.70); ctx.lineTo(W/2,H); ctx.stroke(); ctx.setLineDash([]);
  ctx.font='24px Impact'; ctx.textAlign='center'; ctx.fillStyle='rgba(255,255,255,.75)'; ctx.fillText('TAP',W*.25,H*.86); ctx.fillText('TAP',W*.75,H*.86);
  drawFighter(p1,p1img,false); drawFighter(p2,p2img,true);
  if(lastHitT){ ctx.font=(lastHitText.startsWith('SUPER')?'46px':'36px')+' Impact'; ctx.lineWidth=5; ctx.textAlign='center'; ctx.strokeStyle='#000'; ctx.fillStyle='#ffd31a'; ctx.strokeText(lastHitText,W/2,H*.28); ctx.fillText(lastHitText,W/2,H*.28); }
  if(flash){ ctx.fillStyle='rgba(255,255,255,.20)'; ctx.fillRect(0,0,W,H); }
  ctx.restore();
  hp1El.style.width=hp1+'%'; hp2El.style.width=hp2+'%';
}
draw();
