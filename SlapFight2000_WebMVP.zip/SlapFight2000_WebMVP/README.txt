SlapFight 2000 Web MVP

Start auf dem iPhone:
1) Lade diesen Ordner/ZIP auf einen Webspace oder öffne ihn lokal über eine Dateien-App/Static Server.
2) Öffne index.html in Safari.
3) Tippe Teilen -> Zum Home-Bildschirm.
4) Starte Slap2000 vom Home-Bildschirm.

Am einfachsten ohne eigenen Server:
- Dateien bei Netlify Drop, GitHub Pages oder Vercel hochladen.
- Danach die öffentliche URL in Safari öffnen.

Spiel:
- Linke Bildschirmhälfte: Spieler 1 schlägt.
- Rechte Bildschirmhälfte: Spieler 2 schlägt.
- 100 HP je Spieler.
- Jeder 10. Treffer ist ein Super Slap.
